awk -F ' ' '{print "    {\n      \"path\": "$2",\n      \"method\": ["$1"]\n    },"}' new_api.txt 
